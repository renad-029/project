using System.ComponentModel.DataAnnotations;
namespace SkillBridage.Models
{
    public class Course
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter the course name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter the course description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Please enter the course duration")]
        public string Duration { get; set; }

        [Required(ErrorMessage = "Please enter the course fee")]
        public decimal Fee { get; set; }

        [Required(ErrorMessage = "Please enter the course image")]
        public string Image { get; set; }

        [Required(ErrorMessage = "Please enter the course start date")]
        public string StartDate { get; set; }

        [Required(ErrorMessage = "Please enter the course end date")]
        public string EndDate { get; set; }

        [Required(ErrorMessage = "Please enter the course status")]
        public string Status { get; set; }

        [Required(ErrorMessage = "Please enter the course mentor")]
        public string Mentor { get; set; } //اسم مدرب الكورس

        [Required(ErrorMessage = "Please enter the course category")]
        public string Category { get; set; }

        
    }
}