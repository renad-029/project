using System.ComponentModel.DataAnnotations;
namespace SkillBridage.Models
{
    public class Users
    {   
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your password")]
        public string Password { get; set; }
        
        [Required(ErrorMessage = "Please choose your Role")]
        public Boolean Role { get; set; }
    }
}