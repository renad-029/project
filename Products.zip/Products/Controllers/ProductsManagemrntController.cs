using Microsoft.AspNetCore.Mvc;
using Products.Models;
using System.Linq;
using Products.Data;
namespace Products.Controllers
{
    public class ProductsManagemrntController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public ProductsManagemrntController(ApplicationDbContext context,IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
            _context = context;
        }

        public IActionResult Products()
        {
            return View(_context.Products.ToList());
        }

        
        [Route("Products_Details")]
        [HttpGet]
        public  IActionResult Products_Details()
        {
            return View();
        }

        //ProductsManagemrntController/Products_Details
        
       
    }
}