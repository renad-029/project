using System.ComponentModel.DataAnnotations;
namespace Products.Models
{
    public class Products_Details
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int Product_Id { get; set; }


        [Required]
        public string Color { get; set; }

        [Required]
        public string Image { get; set; }

        [Required]
        public int QTY { get; set; }

        [Required]
        public string Price { get; set; }
      
    }
}