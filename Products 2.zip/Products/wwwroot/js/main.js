
var get_id;

function showmessage(id){
    get_id = id;
    $('#del').modal('show');
}

function DeleteProducts(){ 
    $.ajax({
       url: "DeleteProducts",
       type: "POST",
       data: {id: get_id},

       success: function (result){
           $("#productscontainer").html(result);
           const Toast = Swal.mixin({
               toast: true,
               position: "top-end",
               showConfirmButton: false,
               timer: 3000,
               timerProgressBar: true,
               didOpen: (toast) => {
                   toast.onmouseenter = Swal.stopTimer;
                   toast.onmouseleave = Swal.resumeTimer;
               }
           });
           Toast.fire({
               icon: "success",
               title: "  تم الحذف بنجاح "
           });
       }
    });
}