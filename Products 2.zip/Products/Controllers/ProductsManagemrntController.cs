using Microsoft.AspNetCore.Mvc;
using Products.Models;
using System.Linq;
using Products.Data;
namespace Products.Controllers
{
    public class ProductsManagemrntController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public ProductsManagemrntController(ApplicationDbContext context,IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
            _context = context;
        }

        [Route("Products")]
        public IActionResult Products(Product products)
        {
            var getdata = _context.Products.ToList();
            return View(getdata);
           
        }

        [HttpPost]
        public IActionResult CreateProducts(Product products)
        {
            _context.Products.Add(products);
            _context.SaveChanges();
            return RedirectToAction("Products");
        }

        [Route("DeleteProducts")]
        [HttpPost]       
        public IActionResult DeleteProducts(int id)
        {
            var Products = _context.Products.SingleOrDefault(c => c.Id == id);//search for the products
            if(Products != null) //حصل السجل
            {
               _context.Products.Remove(Products);
               _context.SaveChanges();
            }
            //خاصية عشان تعمل ريفرش بس جزء معين مو كل الصفحة
            var product = _context.Products.ToList(); //read
            return PartialView("_partial/_ProductsPartial",product);
            
        }
        public IActionResult EditProducts(int id)
        {
           var edit_products = _context.Products.SingleOrDefault(c => c.Id == id);
           return View(edit_products);
        }

          public IActionResult UpdateProductsDetails(Product products)
        {
            _context.Products.Update(products);
            _context.SaveChanges();
            return RedirectToAction("Products");
        }

        
        [Route("Products_Details")]
        [HttpGet]
        public  IActionResult Products_Details()
        {
            var Model = _context.Products_Details.ToList(); //read
            var getdata = _context.Products.ToList();
            ViewBag.getdata = getdata;

            var getdatatransport = _context.Products_Details.Join( //نبدا بالفرعي اللي هو transport

                _context.Products,

                Products_Details => Products_Details.Product_Id,
                Products => Products.Id,

                (Products_Details, Products) => new
                {
                   Id = Products_Details.Id,
                   NameProd = Products.Name,
                   DescriptionProd = Products.Description,
                  ColorPro = Products_Details.Color,
                  Imageprod = Products_Details.Image,
                 Price = Products_Details.Price,
                 Quantity = Products_Details.QTY,


                   

                }).ToList();

             ViewBag.getdatatransport = getdatatransport;
            
            
                
            return View(Model);
           
        }


        public IActionResult CreateProductsDetails(Products_Details products_details,IFormFile photo){  
             if(photo==null || photo.Length==0)
            {
            return Content("file not selected");
            }
            
            var path=Path.Combine(_webHostEnvironment.WebRootPath,"images",photo.FileName);
            using (FileStream stream = new FileStream(path, FileMode.Create))
            {
                photo.CopyTo(stream);
                stream.Close();
            }
            products_details.Image=photo.FileName;
            _context.Add(products_details);
            _context.SaveChanges();
            return RedirectToAction("Products_Details");
        }
        


        
        //ProductsManagemrntController/Products_Details
        
       
    }
}