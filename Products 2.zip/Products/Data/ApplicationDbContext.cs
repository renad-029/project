using Products.Models;
using Microsoft.EntityFrameworkCore;
namespace Products.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Products_Details> Products_Details { get; set; }
    }
}